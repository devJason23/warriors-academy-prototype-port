# Warriors Master Schedule — Build Handoff for Claude Code

**Read this entire document before writing any code. This is a prescriptive spec, not a suggestion. Do not make product, design, data, or architecture decisions on your own — follow this document exactly. If something is genuinely blocked (e.g. a missing credential), stop and ask the human; do not improvise a workaround or substitute your own choice.**

---

## 0. What you are building

A public, mobile-first **basketball schedule website** for Warriors Academy (Springfield, MO). It shows the 2026–2027 master schedule for all teams, with a way to filter down to a single team. It reads its data from the club's **Google Sheet** so that when the sheet changes, the site reflects the change automatically.

There is a finished, approved **visual prototype** in this project: `Warriors Master Schedule.dc.html`. That file is written in a proprietary "Design Component" (`.dc.html`) format used by the design tool that produced it. **You will NOT ship that file.** You will rebuild it as a real web app per Section 3, matching its look and behavior pixel-for-pixel. Treat the `.dc.html` file and its screenshots as the **design source of truth**.

Two data files are also included and are the **data source of truth** for the initial build:
- `schedule-data.json` — the fully normalized schedule (use this).
- `schedule-data.js` — the same JSON assigned to `window.WARRIORS_SCHEDULE` (reference only).

### Out of scope (do NOT build now)
- Scores, win/loss records, standings, player/roster stats, points-for/against. A later phase will add these. **Do not add any stats UI or fields now.**
- Authentication / real login. "Coach view" is a simple client-side toggle only (Section 3.7).
- Any feature not explicitly described in Section 3.

---

## 1. Tech stack — REQUIRED, do not substitute

- **Next.js (App Router) + TypeScript**, deployed on **Vercel** (the club already uses Vercel for its marketing site).
- **No CSS framework decisions of your own.** Use plain CSS-in-JS via inline `style` objects / CSS Modules that reproduce the exact tokens in Section 4. Do not introduce Tailwind, MUI, Chakra, shadcn, etc.
- **No state library.** React `useState` only.
- Package manager: `npm`.
- Node 20+.

Project layout (this lives inside the existing `mowarriors.com` Next.js App Router project — the page is the `/schedule` route, not the site root):
```
/app
  /schedule/page.tsx      ← the schedule page (client component), served at mowarriors.com/schedule
  /api/schedule/route.ts  ← server route that returns normalized JSON (Section 5)
/lib
  /normalize.ts           ← the sheet→JSON normalizer (Section 6) — single source of parsing truth
  /types.ts               ← the TypeScript types (Section 2)
/data
  /schedule-data.json     ← committed fallback (copy the file from this project)
/components
  ...                     ← split the UI into components as described in Section 3
```

---

## 2. Data model — EXACT shape

Copy `schedule-data.json` into `/data/schedule-data.json`. Define these types in `/lib/types.ts` and use them everywhere. Do not rename fields.

```ts
export type TeamId = '10U-B'|'12U-B'|'14U-B'|'16U-B'|'18U-B'|'12U-G'|'16U-G'|'14U-G';

export interface Team {
  id: TeamId;
  age: '10U'|'12U'|'14U'|'16U'|'18U';
  gender: 'Boys'|'Girls';
  label: string;          // e.g. "18U Boys"
  comingSoon?: boolean;   // true for teams with no games yet (14U-G)
}

export interface Game {
  id: string;             // stable, e.g. "g41"
  date: string;           // ISO "YYYY-MM-DD" (local calendar day, America/Chicago)
  time: string;           // e.g. "6:00 PM" or "" if unknown
  timeTBD?: boolean;      // true = time is tentative/unconfirmed (show "(TBD)")
  team: TeamId;
  opponent: string;       // may be "" (unknown)
  homeAway: 'home'|'away'|'tbd';
  location: string;       // "Springfield, MO" for home; venue/city for away; "" if unknown
  tentative?: boolean;    // true = whole game is tentative (mark "Tentative · TBD")
}

export interface EventTeam {
  team: TeamId;
  dates: string[];        // ISO days THIS team plays in the event
}

export interface ScheduleEvent {  // multi-day tournaments & postseason
  id: string;
  name: string;           // "Reed Springs Tournament", "State Tournament", "Nationals", ...
  kind: 'tournament'|'postseason';
  startDate: string;      // ISO
  endDate: string;        // ISO
  location: string;
  teams: EventTeam[];
}

export interface CoachNote { date: string; text: string; }   // coach-view only
export interface Holiday   { date: string; name: string; }

export interface ScheduleData {
  season: string;         // "2026–2027"
  home: string;           // "Springfield, MO"
  teams: Team[];
  games: Game[];          // standalone single games (NOT tournament games)
  events: ScheduleEvent[];// tournaments + State/Regionals/Nationals
  holidays: Holiday[];
  coachNotes: CoachNote[];
}
```

**Important distinction:** `games[]` = individual head-to-head games. `events[]` = multi-day tournaments and postseason, where each participating team lists the specific days it plays. A single tournament produces ONE event object shared across teams. Do not flatten events into games.

---

## 3. UI & behavior spec — reproduce exactly

Match `Warriors Master Schedule.dc.html`. Single page. Centered column, `max-width: 760px`, horizontal padding `16px`, dark background `#0B0C0C` with a subtle radial glow at the top (`radial-gradient(120% 60% at 50% -10%, #101514 0%, #0B0C0C 60%)`). Mobile-first; must look correct from **320px wide up through desktop** (see Section 7).

Render order top to bottom:

### 3.1 Header
- Left: the **We Are Warriors logo** (`/public/waw-logo.png`, copied from `assets/waw-logo.png` in this package — already trimmed to a transparent lockup) at `height:44px; width:auto`. Then a 1px `#26282A` vertical divider (32px tall). Then a two-line Space Mono label: `MASTER` / `SCHEDULE · {season}` (10.5px, uppercase, letter-spacing .15em, color `#7C7C84`, line-height 1.55).
- Do NOT recreate the old green "W" tile — it has been replaced by the real logo.
- Right: the Coach view toggle button (Section 3.7).
- Header must `flex-wrap: wrap` so it never overflows on narrow screens.

### 3.2 Summary strip (3 cells, filter-aware)
A 3-column grid with hairline dividers (`gap:1px` over a `#1E2021` background, cells `#111313`, outer `border-radius:14px`). Big number (Archivo 800, `clamp(18px,5.4vw,23px)`) over a Space Mono uppercase label (9.5px, `#7C7C84`).

The three cells change with the active team filter:
- **When filter = All Teams:**
  1. `{total games}` / "Games Scheduled" — where `total = games.length + (sum over every event of every team's dates.length)`.
  2. `{events.length}` / "Tournaments & Events".
  3. `{MON D of earliest date across all games+events}` / "Season Tip-Off".
- **When a specific team is selected:**
  1. `{team games}` / "Games" — where `team games = (standalone games where game.team===T).length + (sum over events of the T entry's dates.length)`.
  2. `{count of events that include T}` / "Tournaments".
  3. `{MON D of that team's earliest date}` / "First Game".

### 3.3 Coach banner (only when Coach view is ON)
Amber pill row (`background:#1A1410`, `border:1px solid #4A3A1E`, text `#E4C36A`) reading: **"Coach view — internal planning notes are visible. Not shown to families."** with a small pulsing amber dot.

### 3.4 "Up Next" hero card
Shows the single soonest upcoming entry (game or event) for the current filter, where "upcoming" means its date (event uses `endDate`) is `>= today`. If none, hide the card entirely.
- Green-tinted card (`linear-gradient(155deg,#12201A,#0F1413)`, `border:1px solid #1F3A2C`, `border-radius:18px`) with a soft radial green glow in the top-right corner.
- Top row: `▸ Up Next{ · TEAMID if filtered}` (Space Mono, `#33C97D`) on the left; a big countdown number on the right — number = whole days from today to the entry date (0 → "Today"), with label "days away" / "day away" / "game day".
- Title row: the type pill (Section 3.6) + the title (Archivo 800, `clamp(21px,6.2vw,27px)`). Title = `vs {opponent}` for a game, or the event name for an event.
- Team badge chip(s) (Section 3.6).
- A divider, then a Space Mono meta row (flex-wrap): `📅 {long date}`, `🕘 {time or "Time TBD"}`, `📍 {venue}`.
- Actions row: a solid green **"＋ Add to Calendar"** link (Section 3.8) and, when the entry has a real away/neutral venue, a **"◎ Directions"** link.

### 3.5 View toggle + team filter
- Two equal-width tab buttons: **SCHEDULE** and **CALENDAR**. Active tab = green fill (`#05B057`, text `#03150C`); inactive = `#111313` with `#202222` border, text `#8A8A86`. Space Mono, uppercase.
- **Team filter chips** below. One chip per: **All Teams**, then each team in `teams[]` order. Each team chip shows an 8px color dot (Section 4 team colors) + its `label`. `comingSoon` teams (14U-G) render disabled, label suffixed `· Soon`, muted, not clickable.
- The chip row **must wrap** (`flex-wrap: wrap`) — never a horizontal scroll. All teams must be visible without scrolling. (This was an explicit fix; do not revert to overflow scroll.)
- Active chip = white fill (`#F4F3F1`, text `#0B0C0C`). Inactive = `#131515` with `#222424` border.
- Selecting a team resets the calendar's selected day to none.

### 3.6 Pills & badges
- **Type pill** (per entry): `HOME` = solid green (`#04954B` on `#03150C`). `AWAY` = transparent with `#45474A` border, `#B3B1B0` text. `TBD` = dashed `#45474A` border. `TOURNAMENT` = transparent with gold border `#C9A24A`, text `#E4C36A`. Postseason shows `STATE` / `REGIONALS` / `NATIONALS` = solid gold `#C9A24A` on `#1A1206`. All pills: Space Mono, 9.5px, 700, uppercase, letter-spacing .1em.
- **Team badge chip:** Space Mono 10px 700, transparent background, 1px border + text in that team's color (Section 4). Text = the raw team id (e.g. `16U-B`).

### 3.7 Schedule view (default)
Upcoming entries grouped by calendar **month**, newest month sections in chronological order, then a final **EARLIER** group for anything already past (currently empty — all 2026–27 games are in the future). Each group header: Space Mono uppercase month label + a hairline rule + an "N events" count on the right.

Each entry is a **card**:
- Left date block (50px, centered): Space Mono month (`OCT`), Archivo 800 day number (25px), Space Mono weekday (`FRI`).
- Left accent border (4px): the **team color** for a game; **gold** `#C9A24A` for a tournament; **bright gold** `#E4C36A` for postseason. Postseason cards also get a faint gold background tint (`#161206`); tournaments a faint warm tint (`#131210`).
- Right content: badge chip(s) + type pill (right-aligned) on one row; then the title (Archivo 700, 16.5px) = `vs {opponent}` (game) or event name; then a Space Mono meta line.
  - Game meta = `{time or "Time TBD"} · {venue}`.
  - Event meta = `{date range} · {N games} · {location}`. Date range formatting: same month → `October 12–15`; cross-month → `January 30 – February 2`; single day → the long date.
  - For an event, when filter = All Teams, show **all** participating team badges; when a team is selected, show only that team's badge and that team's own date range/count.
- If `tentative`, show a dashed amber tag **"Tentative · TBD"**.
- Actions row (games and events, not notes): **＋ Calendar** and, when a real away/neutral venue exists, **◎ Directions** (Section 3.8).
- Coach notes (only when Coach view ON, only on All Teams) appear inline as muted dashed amber rows with an italic "Coach note" label. No actions.

If a selected team has zero entries, show a centered empty state: "No games scheduled for this team yet." + green "Coming soon."

### 3.8 Calendar view
Season months **October 2026 through March 2027**, each as a card containing a 7-column month grid (weekday headers `S M T W T F S`). 
- Day cells are square (`aspect-ratio: 1`). Leading blank cells before day 1 are transparent and non-interactive.
- A day with any game/event shows up to 4 colored dots (team color for games; gold/bright-gold for tournament/postseason). Event days are marked for every day in the event's date range.
- Days with games are tappable; tapping selects the day (toggles off if tapped again) and shows a detail panel **below that month's grid** listing that day's entries as compact cards (badge + pill + title + meta). Selected day cell = white fill.
- A small legend under the calendar: green = Game, gold = Tournament, bright gold = State/Regionals/Nationals.
- When Coach view is ON, coach-note days are also dotted (muted) and appear in the day detail.

### 3.9 Add-to-Calendar & Directions (exact)
- **Add to Calendar** → a Google Calendar template link:
  `https://calendar.google.com/calendar/render?action=TEMPLATE&text={ENC title}&dates={DATES}&location={ENC venue}&ctz=America/Chicago`
  - Title: `Warriors {teamId}{ " vs " + opponent if present}` for games; `Warriors {teamId · if filtered}{event name}` for events.
  - `DATES`: if the game has a **confirmed** time (`time` set and `timeTBD` false), use `YYYYMMDDT{HHMM}00/YYYYMMDDT{HHMM+2h}00` (2-hour default duration, clamp end hour ≤ 23). Otherwise all-day: `{startYYYYMMDD}/{nextDayAfterEndYYYYMMDD}`.
  - Open in a new tab (`target="_blank" rel="noopener"`).
- **Directions** → `https://www.google.com/maps/search/?api=1&query={ENC location}`. Only render when `homeAway !== 'home'` and `location` is set and not a "TBD" string. (Home directions are intentionally omitted until we have the real gym address — see Section 9.)

### 3.10 Footer
Space Mono, muted: `WARRIORS ACADEMY · SPRINGFIELD, MO` over `Home games at {home} · Schedule subject to change`.

### 3.11 Coach view toggle
A header button toggling `coach` state. Off: `🔒 Coach view` (muted). On: `✕ Coach view` (amber). It reveals the coach banner and (on All Teams) the coach-note rows/dots. It is **not** secured — no password, no route. Purely client-side visibility.

---

## 4. Design tokens — use these literals

**Fonts** (Google Fonts): `Archivo` (weights 400–900) for everything; `Space Mono` (400/700) for labels, dates, times, pills, badges.

**Colors**
```
Background base   #0B0C0C      Surface 1  #111313     Surface 2  #141516
Hairline          #1E2021 / #24272 7 / #202222        Card border #1C1E1E
Text              #F4F3F1      Muted #7C7C84 / #9A988F  Faint #56534C / #4A4844
Brand green       #05B057 (hi) / #04954B / #046131 (deep)
Green tints       up-next gradient #12201A→#0F1413, border #1F3A2C
Gold (tournament) #C9A24A       Gold hi (postseason) #E4C36A
```

**Team colors** (age-based, muted OKLCH — do not change these):
```
age → oklch(0.74 0.13 H):  10U→H=190   12U→H=250   14U→H=300   16U→H=32   18U→H=355
```
Both genders of an age share the color; the badge text (`12U-B` vs `12U-G`) disambiguates. `comingSoon` teams use `#3E3C38`.

**Type pill / accent semantics:** border/rail color encodes venue type per Section 3.6; team color is the badge + game rail. Green is reserved for brand/interactive (active tabs, primary buttons); gold is reserved for tournaments/postseason.

---

## 5. `/api/schedule` route — server data source

Create `app/api/schedule/route.ts`. It:
1. Reads the club Google Sheet (Section 8 credentials).
2. Runs `normalize()` from `/lib/normalize.ts` (Section 6) on the raw rows.
3. Returns `ScheduleData` as JSON.
4. On ANY error (missing creds, fetch failure, parse failure), returns the committed `/data/schedule-data.json` instead, and logs the error. The site must never show a blank/broken schedule.

Caching: set `export const revalidate = 60;` (refresh at most once a minute) — this is "effectively instant" for a schedule while protecting the Sheets quota. Do not set a longer cache. Do not use `no-store` (would hammer the API).

The client page fetches `/api/schedule` on load and renders from it; if the fetch fails client-side, it falls back to the imported `/data/schedule-data.json`.

---

## 6. `/lib/normalize.ts` — the parser (single source of truth)

The Google Sheet's **"Master Schedule"** tab is the only tab that matters (the per-team tabs are empty templates — ignore them). Columns, in order:

`A Date | B Time | C Team | D Opponent | E Location | F Home/Away | G Score | H (blank) | I Notes`

`normalize(rows)` must reproduce EXACTLY the logic below (it is what produced `schedule-data.json`; verify your output byte-matches the committed file for the current sheet):

1. **Skip** the header row and any row with an empty Team (col C) — EXCEPT capture annotation rows (see step 8).
2. **Date (A):** values are Excel serial numbers. Convert: `date = new Date(Date.UTC(1899,11,30) + round(serial)*86400000)`, then ISO `YYYY-MM-DD`. (Do not apply timezone offsets; treat as the literal calendar day.)
3. **Time (B):**
   - If the cell text matches `STATE`/`REGIONALS`/`NATIONALS` (case-insensitive) → it is a **postseason tag**, not a time.
   - Else if it contains an `AM`/`PM` clock (e.g. `6:00:00 PM?`) → parse to `H:MM AM/PM`. A trailing `?` sets `timeTBD = true`.
   - Else if it's a fraction `0<x<1` → time of day = `x*1440` minutes → `H:MM AM/PM`.
   - Else no time.
4. **Event detection** (a row belongs to a multi-day event if any of):
   - Time-tag is STATE→`State Tournament`, REGIONALS→`Regionals`, NATIONALS→`Nationals` (kind `postseason`).
   - Home/Away (F) text matches `tournament|classic|slam` → event name = cleaned F (kind `tournament`).
   - Location (E) matches `tournament|tip off` → event name = cleaned E (kind `tournament`).
   - Name cleaning: collapse whitespace; if name contains `Classic` or `Slam`, strip a trailing "tournament"; otherwise normalize a trailing "tournament" to " Tournament"; map `STL Tip off`→`STL Tip-Off`.
   - Event rows are grouped by event name into one `ScheduleEvent`; each team accumulates the set of ISO days it appears on; `startDate`/`endDate` = min/max across included days (per team when filtered later, but store all).
5. **Standalone game** (no event): build a `Game`.
   - `homeAway`: F==="Home" → `home`; F starts with "Away" → `away`; else E==="Home" → `home`; else if F present → `away`; else `tbd`.
   - `location`: home → `"Springfield, MO"`; else E if set and not "Home"; else `""`.
   - `opponent`: col D, strip a leading "possible ", collapse whitespace.
   - `tentative`: true if D contains "possible" or "?".
6. **Absorb opponent-less stray rows:** a standalone game with empty opponent that shares a date with an existing event is folded into that event for its team (this correctly places the 12U-G Nationals row). 
7. **Event location enrichment** — use this exact lookup table (venues confirmed from the club's own site for postseason blanks):
   ```
   Norwood Tournament       → Norwood, MO
   STL Tip-Off              → St. Louis, MO
   Reed Springs Tournament  → Reed Springs, MO · 20277 MO-413
   Winter Slam              → Fieldhouse · Springfield, MO
   Sparta Tournament        → Sparta, MO
   Mercy Warriors Classic   → McAuley Catholic HS · Joplin, MO
   Lady Cougar Classic      → College Heights Christian · Joplin, MO
   State Tournament         → Columbia Fieldhouse · Columbia, MO
   Regionals                → Wichita, KS
   Nationals                → Springfield, MO · NCHBC
   ```
8. **Annotation rows** (empty Team but text in B/E/I):
   - Holidays (text matches `hallo|thanksgiving|christmas|new year`) → `holidays[]`.
   - Skip pure `fall preseason` labels and bare `STATE/REGIONALS/NATIONALS` label rows.
   - Everything else (e.g. "Don working", "ILLNESS WILL HIT", "Buffalo tournament?", "greenfield Jamboree?", "JR Recording?") → `coachNotes[]`. De-dupe by `date+text`.
9. **Teams:** the fixed roster below (do not derive dynamically — 14U-G must appear as `comingSoon` even with no games):
   ```
   10U-B, 12U-B, 14U-B, 16U-B, 18U-B (Boys)   |   12U-G, 16U-G (Girls)   |   14U-G (Girls, comingSoon:true)
   ```
   `label` = `"{age} {gender}"`. Order exactly as listed.
10. Sort `games` by date then time; sort `events` by `startDate`.

**Validation gate:** After implementing, run `normalize()` on the current sheet and assert the result deep-equals `/data/schedule-data.json` (47 games, 10 events, 8 teams, 5 holidays, 14 coachNotes). If it does not match, fix the normalizer — do not edit the JSON to match your parser.

---

## 7. Responsive requirements (non-negotiable)

- Verified working from **320px** to large desktop. Test at 320, 375, 414, 768, 1024, 1440.
- No horizontal page overflow at any width (`document.documentElement.scrollWidth` must equal `window.innerWidth`).
- Header, chip row, up-next meta row, and card action rows all `flex-wrap: wrap`.
- Font sizes for the up-next title and summary numbers use `clamp()` exactly as in Section 3/4.
- Card content uses `min-width: 0` so long venue/opponent text wraps instead of overflowing.
- Calendar grid stays 7 columns at all widths (cells shrink); dots remain visible.
- Tap targets ≥ 40px where practical (chips, tabs, day cells, action links).
- Centered single column, `max-width: 760px`. Do not build a multi-column desktop layout.

---

## 8. Google Sheets connection — do this exactly

Use the **Google Sheets API v4** with a **service account** (most robust, no "publish to web" quirks):
1. In Google Cloud, create a project, enable "Google Sheets API", create a **service account**, download its JSON key.
2. Share the Google Sheet with the service account's email as **Viewer**.
3. Put these in Vercel env vars (and `.env.local` for dev): `GOOGLE_SERVICE_ACCOUNT_EMAIL`, `GOOGLE_PRIVATE_KEY` (escape newlines), `SCHEDULE_SHEET_ID=1c4Z7hCiXDIDMbx4rNDmm5pkqfqYYAFDeG20wnX6m9U8`, `SCHEDULE_SHEET_TAB="Master Schedule"`. The human must share this specific sheet with the service-account email as Viewer.
4. In the route, fetch the "Master Schedule" tab's grid values (use `valueRenderOption=UNFORMATTED_VALUE` so dates come back as serial numbers and times as fractions — the normalizer depends on that).
5. Never expose the key to the client; all Sheets access happens in the API route only.

If the human cannot provide a service account, the fallback is: they "Publish to web" the Master Schedule tab as CSV and give you the URL; you fetch and parse the CSV in the route. **Ask before taking this path** — the service-account path is preferred and is the default.

---

## 9. Decisions already made by the human — treat as fixed

All six were answered. Do not re-ask or change these:
1. **Google Sheet ID = `1c4Z7hCiXDIDMbx4rNDmm5pkqfqYYAFDeG20wnX6m9U8`**, tab `Master Schedule`. Wire up the service-account live sync (Section 8). The human will share the sheet with the service-account email you generate — surface that email to them. Until the share is confirmed, run on the committed `/data/schedule-data.json`.
2. **Home venue stays `"Springfield, MO"` for now.** Directions remain disabled for home games (enabled only for away/neutral with a real venue). Do not invent a home address.
3. **Deploy as a route on the existing site at `mowarriors.com/schedule`.** The main site is a Vercel-hosted Next.js app on that domain; add this as the `/schedule` route within it (not a separate subdomain, not a separate project). Build it so it can be dropped into the existing App Router project.
4. **Use the real logo** at `/public/waw-logo.png` (from `assets/waw-logo.png` here). Header per Section 3.1.
5. **Keep the age-based team colors** exactly as in Section 4.
6. **Sheet column order is fixed** at A–I as in Section 6. Build the normalizer to those columns.

Re-raise with the human only if: the service-account share hasn't happened, or a sheet row appears in a format the normalizer in Section 6 doesn't handle (leave a `// HANDOFF-QUESTION:` and ask).

---

## 10. Definition of done

- `npm run build` succeeds; deploys to Vercel.
- Renders correctly 320px→desktop with zero horizontal overflow.
- Visually matches `Warriors Master Schedule.dc.html` (layout, tokens, spacing, pills, badges, calendar).
- All behaviors in Section 3 work: filter-aware summary, team chips (wrapping, disabled 14U-G), Up Next + countdown, Schedule grouping, Calendar with day-detail, Coach toggle + notes, tentative marking, Add-to-Calendar links, Directions links.
- `/api/schedule` returns live sheet data and falls back to committed JSON on error; `normalize()` output deep-equals the committed JSON for the current sheet.
- No stats/records UI anywhere (reserved for later phase).
- No feature, style, or data decision was made that isn't specified here. If you were tempted to, you left a `// HANDOFF-QUESTION:` comment and asked instead.

---

### Reference files in this package
- `Warriors Master Schedule.dc.html` — design source of truth (do not ship; read for exact styling/behavior).
- `schedule-data.json` — data source of truth + normalizer validation target.
- `schedule-data.js` — same data as a global assignment (reference).
- `assets/waw-logo.png` — the trimmed, transparent We Are Warriors logo. Copy to `/public/waw-logo.png`.
